from xmlrpc.client import ServerProxy

print("The client starts.")
server = None
try:
    while True:
        try:
            cmd = input("> ").split()
            if cmd[0] == 'connect':
                server = ServerProxy(f'http://{cmd[1]}:{cmd[2]}')
            elif cmd[0] == 'getleader':
                print(server.get_leader())
            elif cmd[0] == 'suspend':
                print(server.suspend(int(cmd[1])))
            elif cmd[0] == 'quit':
                break
            else:
                print("Invalid command.")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Invalid command.({e})")
            continue
except KeyboardInterrupt:
    pass
finally:
    print("The client ends.")
