import sys
import time
from threading import Thread, Lock
from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.client import ServerProxy
from datetime import datetime
import random
import socket

socket.setdefaulttimeout(3)

# random.seed(0)

term = 0
TIMER_RANGE = [150, 350]  # milliseconds
timer = random.randint(*TIMER_RANGE)
suspended = False
suspended_period = 1
suspended_start = datetime.utcnow()
servers = []
server_names = {}
voted = False
state = 'follower'
leader = None

timer_reset = False
timeout = False
last_timer_reset = datetime.utcnow()

timer_lock = Lock()


# Get the ID from the command line arguments
id = None
try:
    id = int(sys.argv[1])
except IndexError:
    print("Invalid arguments.")
    exit(1)

# Get the IP and port of the server (and the other servers) from the config file
ip = None
port = None
with open('config.conf') as f:
    lines = f.readlines()
    for l in lines:
        l = l.strip('\n')
        l = l.split()
        server_names[str(l[0])] = f"{l[1]}:{l[2]}"
        if l[0] == str(id):
            ip = l[1]
            port = int(l[2])
        else:
            servers.append(f"http://{l[1]}:{l[2]}")

if ip is None or port is None:
    print("ID not found in the config file. Shutting down ...")
    exit(1)

print(f"Server is started at {ip}:{port}")

print("I am a follower. Term: 0")


# RPC functions
def request_vote(candidate_term, candidate_id):
    global term, voted, state, leader
    timer_lock.acquire()
    leader = ""
    if suspended and (datetime.utcnow() - suspended_start).total_seconds() < suspended_period:
        timer_lock.release()
        return "suspended", False

    if candidate_term > term:
        term = candidate_term
        state = 'follower'
        voted = False

    if not voted and candidate_term == term:
        voted = True
        state = 'follower'
        print(f"Voted for node {candidate_id}")
        leader = candidate_id
        timer_lock.release()
        return term, True
    timer_lock.release()
    return term, False


def append_entry(leader_term, leader_id):
    global leader, term, timer_reset, timeout, timer_lock, voted, state
    timer_lock.acquire()
    if suspended and (datetime.utcnow() - suspended_start).total_seconds() < suspended_period:
        timer_lock.release()
        return "suspended", False
    if leader_term >= term:
        state = 'follower'

        term = leader_term
        timer_reset = True
        timeout = False
        leader = leader_id
        if voted:
            voted = False
            print(f"I am a follower. Term: {term}")

        timer_lock.release()
        return term, True
    timer_lock.release()
    return term, False


def get_leader():
    timer_lock.acquire()
    if suspended and (datetime.utcnow() - suspended_start).total_seconds() < suspended_period:
        timer_lock.release()
        return False
    print(f"Command from client: getleader")
    res = ""
    if leader != "":
        res = f"{leader} {server_names[str(leader)]}"
    print(res)
    timer_lock.release()
    return res


def suspend(period):
    timer_lock.acquire()
    global suspended, suspended_period, suspended_start
    if suspended and (datetime.utcnow() - suspended_start).total_seconds() < suspended_period:
        timer_lock.release()
        return False
    print(f"Command from client: suspend {period}")
    suspended = True
    suspended_period = int(period)
    suspended_start = datetime.utcnow()
    print(f"Sleeping for {period} seconds")
    timer_lock.release()
    return True


# Threads
def rpc_server_thread():
    '''
    This thread runs the RPC server.
    '''
    server = SimpleXMLRPCServer((ip, port), logRequests=False)
    server.register_function(request_vote)
    server.register_function(append_entry)
    server.register_function(get_leader)
    server.register_function(suspend)
    while True:
        server.serve_forever()


def rpc_client_thread():
    '''
    This thread runs the main loop of the server that will make different RPC calls depending on the server state
    '''
    global state, term, id, suspended_period, suspended_start, suspended, timeout, timer_reset, leader, timer_lock, voted
    rpc_clients = [ServerProxy(x) for x in servers]
    while True:
        timer_lock.acquire()

        # If the server is suspended
        if suspended and (datetime.utcnow() - suspended_start).total_seconds() < suspended_period:
            timer_lock.release()
            continue

        # If the server is the leader
        if state == 'leader':
            timer_lock.release()
            for peer in rpc_clients:
                try:
                    peer_term, approved = peer.append_entry(term, id)
                except:
                    continue
                if peer_term == 'suspended':
                    continue
                timer_lock.acquire()
                if peer_term > term:
                    term = peer_term
                    voted = False
                    state = 'follower'
                    print(f"I am a follower. Term: {term}")
                    timer_lock.release()
                    break
                timer_lock.release()
            time.sleep(0.05)  # 50 ms between heartbeat messages
            timer_lock.acquire()
            timer_reset = True
            timer_lock.release()
            continue

        # If the heartbeat timed out (and didn't vote for the next term)
        if timeout and not voted:
            timeout = False
            if state == 'follower':

                # Become candidate
                print('The leader is dead')
                state = 'candidate'
                term += 1
                print(f"I am a candidate. Term: {term}")
                timer_reset = True
                timeout = False
                timer_lock.release()

                # Start the voting process
                votes = 1
                voted = True
                refused = 0
                print(f"Voted for node {id}")
                for peer in rpc_clients:
                    try:
                        peer_term, approved = peer.request_vote(term, id)
                    except Exception as e:
                        continue
                    if peer_term == 'suspended':
                        continue

                    # Become follower if there is a node with a bigger term number
                    if peer_term > term:
                        timer_lock.acquire()
                        term = peer_term
                        voted = False
                        state = 'follower'
                        timer_lock.release()
                        break
                    if approved:
                        votes += 1
                    else:
                        refused += 1
                print(f"Votes received")

                # Check the voting outcome
                timer_lock.acquire()
                if state == 'follower' or refused > votes:
                    timeout = False
                    state = 'follower'
                    print(f"I am a follower. Term: {term}")
                    timer_reset = True
                    continue
                state = 'leader'
                leader = id
                timer_reset = True
                print(f"I am a leader. Term: {term}")
        timer_lock.release()


def timer_thread_function():
    '''
    This thread keeps track of the time for the server. It checks for timeouts and timer resets.
    It also brings back the server if the suspension period is over.
    '''
    global last_timer_reset, timer_reset, timeout, suspended, state
    while True:

        timer_lock.acquire()
        if suspended and (datetime.utcnow() - suspended_start).total_seconds() < suspended_period:
            timer_lock.release()
            time.sleep(0.05)
            continue

        # If the suspension period is over, bring back the server
        if suspended:
            state = 'follower'
            suspended = False
            timer_reset = True

        # Resets the timer
        if timer_reset:
            timeout = False
            last_timer_reset = datetime.utcnow()
            timer_reset = False

        # Triggers timeout
        elif (datetime.utcnow() - last_timer_reset).total_seconds() * 1000 > timer:
            timeout = True
            last_timer_reset = datetime.utcnow()
        timer_lock.release()
        time.sleep(0.003)


# Start the threads
server_thread = Thread(target=rpc_server_thread)
client_thread = Thread(target=rpc_client_thread)
timer_thread = Thread(target=timer_thread_function)

server_thread.start()
client_thread.start()
timer_thread.start()
