from xmlrpc.server import SimpleXMLRPCServer
import sys
import os
from pathlib import Path

Path(os.path.join(os.getcwd(), 'server_data')).mkdir(parents=True, exist_ok=True)

ip, port = None, None

try:
    ip = sys.argv[1]
    port = int(sys.argv[2])
except Exception as e:
    print("Invalid arguments.")
    exit()

with SimpleXMLRPCServer((ip, port)) as server:
    server.register_introspection_functions()


    def send_file(filename, data):
        file_path = os.path.join(os.getcwd(), 'server_data', filename)
        if Path(file_path).exists():
            print(f"{filename} not saved")
            return False
        with open(file_path, "w+b") as f:
            f.write(data.data)
        print(f"{filename} saved")
        return True


    server.register_function(send_file)


    def list_files():
        return os.listdir(os.path.join(os.getcwd(), 'server_data'))


    server.register_function(list_files)


    def delete_file(filename):
        file_path = os.path.join(os.getcwd(), 'server_data', filename)
        if not Path(file_path).exists():
            print(f'{filename} not deleted')
            return False
        os.remove(file_path)
        print(f"{filename} deleted")
        return True


    server.register_function(delete_file)


    def get_file(filename):
        res = b""
        file_path = os.path.join(os.getcwd(), 'server_data', filename)
        if not Path(file_path).exists():
            print(f"No such file : {filename}")
            return False
        with open(file_path, 'rb') as f:
            res = f.read()
        print(f"File send : {filename}")
        return bytearray(res)


    server.register_function(get_file)


    def calculate(expression):
        try:
            data = expression.split(' ')
            if data[0] not in ['+', '-', '*', '/', '>', '<', '<=', '>=']:
                print(f"{expression} -- not done")

                return False, 'Wrong expression'
            try:
                float(data[1])
                float(data[2])
            except TypeError:
                print(f"{expression} -- not done")
                return False, 'Wrong expression'
            if float(data[2]) == 0 and data[0] == '/':
                print(f"{expression} -- not done")
                return False, 'Division by zero'
            operator_codes = {
                '+': (lambda x, y: x + y),
                '*': (lambda x, y: x * y),
                '-': (lambda x, y: x - y),
                '/': (lambda x, y: x / y),
                '>': (lambda x, y: x > y),
                '<': (lambda x, y: x < y),
                '>=': (lambda x, y: x >= y),
                '<=': (lambda x, y: x <= y)
            }
            res = operator_codes[data[0]](float(data[1]), float(data[2]))
            if '.' not in data[1] and '.' not in data[2]:
                res = operator_codes[data[0]](int(data[1]), int(data[2]))
        except Exception as e:
            print(f"{expression} -- not done")
            return False, str(e)
        print(f"{expression} -- done")
        return True, res


    server.register_function(calculate)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Server is stopping")
        exit(0)
