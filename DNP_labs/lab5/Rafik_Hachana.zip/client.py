import xmlrpc.client
from pathlib import Path
import os
import sys

Path(os.path.join(os.getcwd(), 'client_data')).mkdir(parents=True, exist_ok=True)

ip, port = None, None

try:
    ip = sys.argv[1]
    port = int(sys.argv[2])
except Exception as e:
    print("Invalid arguments.")
    exit()


def load_file(filename):
    res = b""
    if not Path(os.path.join(os.getcwd(), 'client_data', filename)).exists():
        return False
    with open(os.path.join(os.getcwd(), 'client_data', filename), 'rb') as f:
        res = f.read()
    return bytearray(res)


s = xmlrpc.client.ServerProxy(f'http://{ip}:{port}')
while True:
    try:
        command = input('\nEnter the command: ').split()
        try:
            if command[0] == 'quit':
                raise KeyboardInterrupt
            elif command[0] == 'send':
                file = load_file(command[1])
                if not file:
                    print('Not completed')
                    print('No such file')
                    continue
                ret = s.send_file(command[1], file)
                if not ret:
                    print('Not completed')
                    print('File already exists')
                else:
                    print('Completed')
            elif command[0] == 'list':
                files = s.list_files()
                for i in files:
                    print(i)
                print('Completed')
            elif command[0] == 'delete':
                if s.delete_file(command[1]):
                    print('Completed')
                else:
                    print('Not completed')
                    print('No such file')
            elif command[0] == 'get':
                f = s.get_file(command[1])
                local_name = command[1]
                if len(command)==3:
                    local_name = command[2]
                if not f:
                    print('Not completed')
                    print('No such file')
                elif Path(os.path.join(os.getcwd(), 'client_data', local_name)).exists():
                    print('Not completed')
                    print('File already exists')
                else:
                    with open(os.path.join(os.getcwd(), 'client_data', local_name), 'w+b') as file:
                        file.write(f.data)
                    print('Completed')
            elif command[0] == 'calc':
                res = s.calculate(" ".join(command[1:]))
                if res[0]:
                    print(res[1])
                    print('Completed')
                else:
                    print('Not completed')
                    print(res[1])
            else:
                print('Not completed')
                print('Wrong command')
        except IndexError:
            print('Not completed')
            print('Wrong command')

    except KeyboardInterrupt:
        print("Client is stopping")
        break
